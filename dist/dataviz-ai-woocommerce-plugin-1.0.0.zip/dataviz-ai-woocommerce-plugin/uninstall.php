<?php
/**
 * Uninstall Dataviz AI for WooCommerce.
 *
 * Fires when the plugin is deleted from WordPress (not on deactivate).
 *
 * @package Dataviz_AI_WooCommerce
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Clear scheduled events.
wp_clear_scheduled_hook( 'dataviz_ai_cleanup_chat_history' );
wp_clear_scheduled_hook( 'dataviz_ai_process_email_digests' );

// Plugin settings.
delete_option( 'dataviz_ai_wc_settings' );

// Transients (prefix patterns used by the plugin).
$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_dataviz%' OR option_name LIKE '_transient_timeout_dataviz%'"
);

// User meta (all users).
$meta_keys = array(
	'dataviz_ai_session_id',
	'dataviz_ai_onboarding_completed',
	'dataviz_ai_onboarding_completed_at',
	'dataviz_ai_onboarding_version',
	'dataviz_ai_onboarding_skipped',
	'dataviz_ai_onboarding_skipped_at',
	'dataviz_ai_onboarding_current_step',
);
foreach ( $meta_keys as $key ) {
	delete_metadata( 'user', 0, $key, '', true );
}

// Custom tables.
$tables = array(
	$wpdb->prefix . 'dataviz_ai_chat_history',
	$wpdb->prefix . 'dataviz_ai_feature_requests',
	$wpdb->prefix . 'dataviz_ai_support_requests',
	$wpdb->prefix . 'dataviz_ai_email_digests',
);
foreach ( $tables as $table ) {
	// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from known list.
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
}
