# Release checklist — Dataviz AI for WooCommerce

Use this before tagging a version, publishing to WordPress.org, or distributing a ZIP.

## Version & metadata

- [ ] Bump **`Version`** in `dataviz-ai-woocommerce.php` and **`DATAVIZ_AI_WC_VERSION`** (same value).
- [ ] Bump **`Stable tag`** in `readme.txt` to match.
- [ ] Update **`Tested up to`** (WordPress) and **`WC tested up to`** in both the main plugin header and `readme.txt`.
- [ ] Set **`Plugin URI`** and **`Author URI`** to real URLs (replace `example.com` placeholders).
- [ ] Set **`Contributors`** in `readme.txt` to your WordPress.org username(s).

## Code & security

- [ ] Run your automated tests (`npm test`, PHP lint if applicable).
- [ ] Confirm **no API keys** in the repo (`config.php` remains gitignored).
- [ ] Smoke-test: activate on a clean site, chat, chart, digest **Preview**, deactivate, **delete** plugin (verify `uninstall.php` removes tables/options as expected on a throwaway DB).

## Packaging

- [ ] From repo root: `chmod +x bin/build-release.sh && ./bin/build-release.sh`
- [ ] Install the generated ZIP on a fresh WP + WooCommerce site before publishing.

## WordPress.org (if submitting)

- [ ] **Assets**: banner 1544×500 / 772×250, icon 256×256 / 128×128 (optional but recommended).
- [ ] **Screenshots**: 1–5 PNGs referenced in `readme.txt`.
- [ ] Read [Plugin Guidelines](https://developer.wordpress.org/plugins/wordpress-org/detailed-plugin-guidelines/).
- [ ] SVN: tag release, copy `readme.txt` and `dataviz-ai-woocommerce.php` to `/trunk`, tag `/tags/x.y.z/`.

## Post-release

- [ ] Git tag: `git tag v1.0.0 && git push origin v1.0.0`
- [ ] Announce (site, video, social) with changelog summary.
